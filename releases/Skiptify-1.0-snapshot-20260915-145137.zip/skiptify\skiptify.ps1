[CmdletBinding()]
param(
    [int]$HostPid = 0,
    [string]$StopEventName = ""
)

$CheckIntervalMs = 200
$TriggerCount = 2
$StartupTimeoutMs = 10000
$RecoveryTimeoutMs = 180000
$StartupStableChecks = 3
$RecoveryStableChecks = 5
$PostReadyDelayMs = 1200
$PostNextDelayMs = 500
$script:SpotifyExecutablePath = $null
$logRoot = if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { $PSScriptRoot } else { Join-Path $env:LOCALAPPDATA "Skiptify\Logs" }
$LogDirectory = $logRoot
$LogPath = Join-Path -Path $LogDirectory -ChildPath "skiptify.log"
$script:StopEvent = $null
$script:EngineMutex = $null
$script:StatusOutputEnabled = $HostPid -gt 0

$IgnoredTitles = @(
    "Spotify Free"
)

if ($null -eq ("SpotifyControl" -as [type])) {
    Add-Type @"
using System;
using System.Runtime.InteropServices;

public class SpotifyControl
{
    [DllImport("user32.dll", SetLastError = true)]
    public static extern IntPtr SendMessageTimeout(
        IntPtr hWnd,
        uint Msg,
        IntPtr wParam,
        IntPtr lParam,
        uint flags,
        uint timeout,
        out IntPtr result
    );

    const uint WM_APPCOMMAND = 0x0319;

    public static void Next(IntPtr hWnd)
    {
        Send(hWnd, new IntPtr(11 << 16));
    }

    public static void Play(IntPtr hWnd)
    {
        Send(hWnd, new IntPtr(46 << 16));
    }

    public static void Pause(IntPtr hWnd)
    {
        Send(hWnd, new IntPtr(47 << 16));
    }

    private static void Send(IntPtr hWnd, IntPtr command)
    {
        IntPtr result;
        const uint SMTO_ABORTIFHUNG = 0x0002;
        if (SendMessageTimeout(hWnd, WM_APPCOMMAND, hWnd, command, SMTO_ABORTIFHUNG, 1000, out result) == IntPtr.Zero)
        {
            throw new InvalidOperationException("Spotify window did not respond within 1000 ms.");
        }
    }
}
"@
}

if ($null -eq ("WindowControl" -as [type])) {
    Add-Type @"
using System;
using System.Runtime.InteropServices;

public class WindowControl
{
    [DllImport("user32.dll")]
    public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    public static extern bool IsIconic(IntPtr hWnd);

    public const int SW_SHOWMINNOACTIVE = 7;
}
"@
}

function Write-SkiptifyLog {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message
    )

    $line = "{0} {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"), $Message

    try {
        if (-not (Test-Path -LiteralPath $script:LogDirectory -PathType Container)) {
            New-Item -ItemType Directory -Path $script:LogDirectory -Force | Out-Null
        }
        $incomingBytes = [Text.Encoding]::UTF8.GetByteCount($line + [Environment]::NewLine)
        if (Test-Path -LiteralPath $script:LogPath -PathType Leaf) {
            $current = Get-Item -LiteralPath $script:LogPath -ErrorAction Stop
            if ($current.Length + $incomingBytes -gt 1MB) {
                $archive = Join-Path $script:LogDirectory "skiptify.1.log"
                if (Test-Path -LiteralPath $archive -PathType Leaf) {
                    Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
                }
                Move-Item -LiteralPath $script:LogPath -Destination $archive -Force -ErrorAction Stop
            }
        }
        Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8 -ErrorAction Stop
    }
    catch {
        # An unusual ACL or read-only profile should not stop monitoring. Use the
        # script directory as a fallback when the per-user log directory fails.
        if ($script:LogDirectory -ne $PSScriptRoot) {
            try {
                $script:LogDirectory = $PSScriptRoot
                $script:LogPath = Join-Path $PSScriptRoot "skiptify.log"
                Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8 -ErrorAction Stop
                return
            }
            catch {
            }
        }
        Write-Warning "Skiptify could not write to '$script:LogPath': $($_.Exception.Message)"
    }
}

function Write-SkiptifyStatus {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("Memulai", "Aktif", "Memulihkan", "Menghentikan", "Off", "Gagal", "Konflik")]
        [string]$Status,
        [string]$Message = ""
    )

    if (-not $script:StatusOutputEnabled) {
        return
    }

    try {
        $json = [PSCustomObject]@{
            status = $Status
            message = $Message
            timestamp = (Get-Date).ToString("o")
        } | ConvertTo-Json -Compress
        [Console]::Out.WriteLine($json)
        [Console]::Out.Flush()
    }
    catch {
        # Status reporting must never stop the Spotify worker.
    }
}

function Test-SkiptifyStopRequested {
    if ($script:StopEvent) {
        try {
            if ($script:StopEvent.WaitOne(0)) {
                return $true
            }
        }
        catch {
            return $true
        }
    }

    if ($HostPid -gt 0) {
        try {
            return [Diagnostics.Process]::GetProcessById($HostPid).HasExited
        }
        catch {
            return $true
        }
    }

    return $false
}

function Initialize-SkiptifyControl {
    if (-not [string]::IsNullOrWhiteSpace($StopEventName)) {
        try {
            $script:StopEvent = [Threading.EventWaitHandle]::OpenExisting($StopEventName)
        }
        catch {
            $script:StopEvent = $null
        }
    }

    try {
        $script:EngineMutex = New-Object System.Threading.Mutex($false, "Local\Skiptify.Engine.1.0")
        $acquired = $false
        try {
            $acquired = $script:EngineMutex.WaitOne(0)
        }
        catch [System.Threading.AbandonedMutexException] {
            $acquired = $true
        }
        if (-not $acquired) {
            Write-SkiptifyStatus -Status "Konflik" -Message "Skiptify sudah berjalan."
            try { $script:EngineMutex.Dispose() } catch {}
            $script:EngineMutex = $null
            return $false
        }
        return $true
    }
    catch {
        Write-SkiptifyStatus -Status "Gagal" -Message "Tidak dapat mengunci proses Skiptify."
        return $false
    }
}

function Dispose-SkiptifyControl {
    if ($script:EngineMutex) {
        try { $script:EngineMutex.ReleaseMutex() } catch {}
        try { $script:EngineMutex.Dispose() } catch {}
        $script:EngineMutex = $null
    }
    if ($script:StopEvent) {
        try { $script:StopEvent.Dispose() } catch {}
        $script:StopEvent = $null
    }
}

function Get-SpotifyProcesses {
    @(Get-Process -Name Spotify -ErrorAction SilentlyContinue)
}

function Get-SpotifyWindowSnapshot {
    $processes = @(Get-SpotifyProcesses)

    if ($processes.Count -eq 0) {
        return $null
    }

    $windowedProcess = $processes |
        Where-Object {
            try {
                $_.MainWindowHandle -ne [IntPtr]::Zero
            }
            catch {
                $false
            }
        } |
        Select-Object -First 1

    if ($windowedProcess) {
        return $windowedProcess
    }

    return ($processes | Select-Object -First 1)
}

function Test-SpotifyWindow {
    param(
        [Parameter(Mandatory = $true)]
        $Process,
        [switch]$RequireFreeTitle
    )

    try {
        if ($Process.MainWindowHandle -eq [IntPtr]::Zero -or -not $Process.Responding) {
            return $false
        }

        if ($RequireFreeTitle -and $Process.MainWindowTitle -ne "Spotify Free") {
            return $false
        }

        return $true
    }
    catch {
        return $false
    }
}

function Get-SpotifyMainWindow {
    $spotify = Get-SpotifyWindowSnapshot

    if ($spotify -and (Test-SpotifyWindow -Process $spotify) -and $spotify.MainWindowTitle -ne "") {
        return $spotify
    }

    return $null
}

function Get-SpotifyWindowByIdentity {
    param(
        [Parameter(Mandatory = $true)]
        [int]$ProcessId,
        [Parameter(Mandatory = $true)]
        [IntPtr]$WindowHandle,
        [switch]$RequireFreeTitle
    )

    $spotify = Get-SpotifyWindowSnapshot

    if (-not $spotify -or -not (Test-SpotifyWindow -Process $spotify -RequireFreeTitle:$RequireFreeTitle)) {
        return $null
    }

    try {
        if ($spotify.Id -ne $ProcessId -or [Int64]$spotify.MainWindowHandle -ne [Int64]$WindowHandle) {
            return $null
        }
    }
    catch {
        return $null
    }

    return $spotify
}

function Get-SpotifyWindowDescription {
    param($Process)

    if ($null -eq $Process) {
        return "PID=<none>; Handle=<none>; Title=<none>"
    }

    try {
        return "PID={0}; Handle={1}; Title='{2}'" -f $Process.Id, $Process.MainWindowHandle, $Process.MainWindowTitle
    }
    catch {
        return "PID=<unavailable>; Handle=<unavailable>; Title=<unavailable>"
    }
}

function New-SkiptifyResult {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("Started", "CommandsSent", "TimedOut", "Failed")]
        [string]$Status,
        [string]$Reason,
        $Process
    )

    [PSCustomObject]@{
        Status = $Status
        Reason = $Reason
        Process = $Process
    }
}

function Start-SpotifyUri {
    # Cache the running executable before recovery kills its processes.
    # The URI remains a fallback for installations that cannot launch directly.
    $candidates = @($script:SpotifyExecutablePath)
    if ($env:APPDATA) {
        $candidates += Join-Path $env:APPDATA "Spotify\Spotify.exe"
    }
    foreach ($candidate in $candidates) {
        if ([string]::IsNullOrWhiteSpace($candidate) -or -not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            continue
        }
        try {
            Start-Process -FilePath $candidate -WindowStyle Hidden -ErrorAction Stop
            Write-SkiptifyLog "Spotify executable launched hidden."
            return $true
        }
        catch {
            Write-SkiptifyLog "Direct Spotify launch failed: $($_.Exception.Message)"
        }
    }

    try {
        Start-Process -FilePath "spotify:" -WindowStyle Hidden -ErrorAction Stop
        Write-SkiptifyLog "Spotify URI opened."
        return $true
    }
    catch {
        Write-SkiptifyLog "Spotify URI failed to open: $($_.Exception.Message)"
        return $false
    }
}

function Stop-SpotifyProcesses {
    param(
        [Parameter(Mandatory = $true)]
        [array]$Processes
    )

    $Processes | Stop-Process -Force -ErrorAction Stop
}

function Wait-SpotifyProcessesExit {
    param(
        [Parameter(Mandatory = $true)]
        [array]$Processes,
        [int]$TimeoutMs = 5000
    )

    $ids = @($Processes | ForEach-Object { $_.Id })
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    while ($ids.Count -gt 0 -and $stopwatch.ElapsedMilliseconds -lt $TimeoutMs) {
        $ids = @($ids | Where-Object {
            try { -not (Get-Process -Id $_ -ErrorAction Stop).HasExited }
            catch { $false }
        })
        if ($ids.Count -gt 0) {
            Start-Sleep -Milliseconds 50
        }
    }
}

function Minimize-SpotifyWindow {
    param(
        [Parameter(Mandatory = $true)]
        [IntPtr]$WindowHandle
    )

    if ($WindowHandle -ne [IntPtr]::Zero -and -not [WindowControl]::IsIconic($WindowHandle)) {
        [WindowControl]::ShowWindowAsync($WindowHandle, [WindowControl]::SW_SHOWMINNOACTIVE) | Out-Null
    }
}

function Send-SpotifyAppCommand {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("Next", "Play", "Pause")]
        [string]$Command,
        [Parameter(Mandatory = $true)]
        [IntPtr]$WindowHandle
    )

    switch ($Command) {
        "Next"  { [SpotifyControl]::Next($WindowHandle) }
        "Play"  { [SpotifyControl]::Play($WindowHandle) }
        "Pause" { [SpotifyControl]::Pause($WindowHandle) }
    }
}

function Wait-ForSpotifyMainWindow {
    param(
        [int]$TimeoutMs = $StartupTimeoutMs,
        [int]$RequiredStableChecks = $StartupStableChecks
    )

    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $stableCount = 0
    $expectedProcessId = $null
    $expectedWindowHandle = $null
    $lastSnapshot = $null

    while ($stopwatch.ElapsedMilliseconds -lt $TimeoutMs) {
        if (Test-SkiptifyStopRequested) {
            return New-SkiptifyResult -Status "Stopped" -Reason "Permintaan berhenti diterima."
        }

        $snapshot = Get-SpotifyWindowSnapshot
        $lastSnapshot = $snapshot

        if ($snapshot) {
            Minimize-SpotifyWindow -WindowHandle $snapshot.MainWindowHandle
        }

        if ($snapshot -and (Test-SpotifyWindow -Process $snapshot)) {
            try {
                $sameWindow = $snapshot.Id -eq $expectedProcessId -and [Int64]$snapshot.MainWindowHandle -eq [Int64]$expectedWindowHandle
                if ($sameWindow) {
                    $stableCount++
                }
                else {
                    $expectedProcessId = $snapshot.Id
                    $expectedWindowHandle = $snapshot.MainWindowHandle
                    $stableCount = 1
                }

                if ($stableCount -ge $RequiredStableChecks) {
                    return New-SkiptifyResult -Status "Started" -Process $snapshot
                }
            }
            catch {
                $stableCount = 0
                $expectedProcessId = $null
                $expectedWindowHandle = $null
            }
        }
        else {
            $stableCount = 0
            $expectedProcessId = $null
            $expectedWindowHandle = $null
        }

        Start-Sleep -Milliseconds $CheckIntervalMs
    }

    return New-SkiptifyResult -Status "TimedOut" -Reason "No responsive Spotify window became stable within $TimeoutMs ms." -Process $lastSnapshot
}

function Wait-ForSpotifyFreeReady {
    param(
        [int]$TimeoutMs = $RecoveryTimeoutMs,
        [int]$RequiredStableChecks = $RecoveryStableChecks,
        [switch]$IgnoreStop
    )

    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $stableCount = 0
    $expectedProcessId = $null
    $expectedWindowHandle = $null
    $lastSnapshot = $null

    while ($stopwatch.ElapsedMilliseconds -lt $TimeoutMs) {
        if (-not $IgnoreStop -and (Test-SkiptifyStopRequested)) {
            return New-SkiptifyResult -Status "Stopped" -Reason "Permintaan berhenti diterima."
        }

        $snapshot = Get-SpotifyWindowSnapshot
        $lastSnapshot = $snapshot

        if ($snapshot) {
            Minimize-SpotifyWindow -WindowHandle $snapshot.MainWindowHandle
        }

        if ($snapshot -and (Test-SpotifyWindow -Process $snapshot -RequireFreeTitle)) {
            try {
                $sameWindow = $snapshot.Id -eq $expectedProcessId -and [Int64]$snapshot.MainWindowHandle -eq [Int64]$expectedWindowHandle
                if ($sameWindow) {
                    $stableCount++
                }
                else {
                    $expectedProcessId = $snapshot.Id
                    $expectedWindowHandle = $snapshot.MainWindowHandle
                    $stableCount = 1
                }

                if ($stableCount -ge $RequiredStableChecks) {
                    Write-SkiptifyLog "Spotify recovery ready after $stableCount stable checks: $(Get-SpotifyWindowDescription $snapshot)"
                    return New-SkiptifyResult -Status "Started" -Process $snapshot
                }
            }
            catch {
                $stableCount = 0
                $expectedProcessId = $null
                $expectedWindowHandle = $null
            }
        }
        else {
            $stableCount = 0
            $expectedProcessId = $null
            $expectedWindowHandle = $null
        }

        Start-Sleep -Milliseconds $CheckIntervalMs
    }

    $reason = "Spotify Free was not stable for $RequiredStableChecks checks within $TimeoutMs ms. Last seen: $(Get-SpotifyWindowDescription $lastSnapshot)"
    Write-SkiptifyLog "Recovery timed out: $reason"
    return New-SkiptifyResult -Status "TimedOut" -Reason $reason -Process $lastSnapshot
}

function Start-SpotifySmooth {
    Write-SkiptifyLog "Spotify was not running; starting without playback commands."

    if (Test-SkiptifyStopRequested) {
        return New-SkiptifyResult -Status "Stopped" -Reason "Permintaan berhenti diterima."
    }

    if (-not (Start-SpotifyUri)) {
        return New-SkiptifyResult -Status "Failed" -Reason "Unable to open Spotify URI."
    }

    if (Test-SkiptifyStopRequested) {
        return New-SkiptifyResult -Status "Stopped" -Reason "Permintaan berhenti diterima."
    }

    $ready = Wait-ForSpotifyMainWindow
    if ($ready.Status -ne "Started") {
        $reason = "Spotify did not present a stable responsive window after startup. Last seen: $(Get-SpotifyWindowDescription $ready.Process)"
        Write-SkiptifyLog "Startup failed: $reason"
        return New-SkiptifyResult -Status "Failed" -Reason $reason -Process $ready.Process
    }

    Minimize-SpotifyWindow -WindowHandle $ready.Process.MainWindowHandle
    Write-SkiptifyLog "Spotify startup completed: $(Get-SpotifyWindowDescription $ready.Process)"
    return $ready
}

function Restart-SpotifySmooth {
    Write-SkiptifyLog "Recovery started."

    if (Test-SkiptifyStopRequested) {
        return New-SkiptifyResult -Status "Stopped" -Reason "Permintaan berhenti diterima."
    }

    $oldSpotify = Get-SpotifyMainWindow
    if ($oldSpotify) {
        try {
            Send-SpotifyAppCommand -Command "Pause" -WindowHandle $oldSpotify.MainWindowHandle
        }
        catch {
            Write-SkiptifyLog "Could not pause Spotify before recovery: $($_.Exception.Message)"
        }
    }

    Start-Sleep -Milliseconds 100

    $oldProcesses = @(Get-SpotifyProcesses)
    foreach ($process in $oldProcesses) {
        try {
            if ($process.Path) {
                $script:SpotifyExecutablePath = $process.Path
                break
            }
        }
        catch {
            # Some packaged installations do not expose their executable path.
        }
    }
    if (Test-SkiptifyStopRequested) {
        return New-SkiptifyResult -Status "Stopped" -Reason "Permintaan berhenti diterima sebelum Spotify dihentikan." -Process $oldSpotify
    }
    if ($oldProcesses.Count -gt 0) {
        try {
            Stop-SpotifyProcesses -Processes $oldProcesses
        }
        catch {
            $reason = "Could not stop Spotify during recovery: $($_.Exception.Message)"
            Write-SkiptifyLog "Recovery failed: $reason"
            return New-SkiptifyResult -Status "Failed" -Reason $reason -Process $oldSpotify
        }

        Wait-SpotifyProcessesExit -Processes $oldProcesses -TimeoutMs 5000
    }

    if (-not (Start-SpotifyUri)) {
        $reason = "Unable to open Spotify URI during recovery."
        Write-SkiptifyLog "Recovery failed: $reason"
        return New-SkiptifyResult -Status "Failed" -Reason $reason
    }

    # If Spotify was already terminated when Off arrived, restore the app but
    # deliberately skip Next/Play so the user's session is not altered.
    if (Test-SkiptifyStopRequested) {
        $restored = Wait-ForSpotifyFreeReady -TimeoutMs ([Math]::Min(10000, $RecoveryTimeoutMs)) -RequiredStableChecks 3 -IgnoreStop
        if ($restored.Status -eq "Started") {
            Minimize-SpotifyWindow -WindowHandle $restored.Process.MainWindowHandle
        }
        return New-SkiptifyResult -Status "Stopped" -Reason "Spotify dipulihkan tanpa perintah playback." -Process $restored.Process
    }

    $recoveryTimer = [System.Diagnostics.Stopwatch]::StartNew()
    while ($true) {
        $remainingMs = $RecoveryTimeoutMs - [int]$recoveryTimer.ElapsedMilliseconds
        if ($remainingMs -le $PostReadyDelayMs) {
            return New-SkiptifyResult -Status "TimedOut" -Reason "Spotify did not remain ready within the recovery deadline."
        }
        $ready = Wait-ForSpotifyFreeReady -TimeoutMs ($remainingMs - $PostReadyDelayMs)
        if ($ready.Status -eq "Stopped") {
            # Spotify has already been launched after the old process was
            # terminated. Complete a short, stop-ignoring readiness wait so
            # closing the UI never leaves Spotify half-started.
            $restoreTimeout = [Math]::Min(10000, [Math]::Max(1000, $remainingMs))
            $restored = Wait-ForSpotifyFreeReady -TimeoutMs $restoreTimeout -RequiredStableChecks 3 -IgnoreStop
            if ($restored.Status -eq "Started") {
                Minimize-SpotifyWindow -WindowHandle $restored.Process.MainWindowHandle
            }
            return New-SkiptifyResult -Status "Stopped" -Reason "Spotify dipulihkan tanpa perintah playback." -Process $restored.Process
        }
        if ($ready.Status -ne "Started") {
            return $ready
        }

        $processId = $ready.Process.Id
        $windowHandle = $ready.Process.MainWindowHandle
        Minimize-SpotifyWindow -WindowHandle $windowHandle

        Start-Sleep -Milliseconds $PostReadyDelayMs

        $confirmedSpotify = Get-SpotifyWindowByIdentity -ProcessId $processId -WindowHandle $windowHandle -RequireFreeTitle
        if ($confirmedSpotify) {
            break
        }

        Write-SkiptifyLog "Spotify changed during the post-ready delay; waiting again. Last seen: $(Get-SpotifyWindowDescription (Get-SpotifyWindowSnapshot))"
    }

    if (Test-SkiptifyStopRequested) {
        return New-SkiptifyResult -Status "Stopped" -Reason "Permintaan berhenti diterima sebelum perintah playback." -Process $confirmedSpotify
    }

    try {
        Send-SpotifyAppCommand -Command "Next" -WindowHandle $windowHandle
        Write-SkiptifyLog "Next command sent: $(Get-SpotifyWindowDescription $confirmedSpotify)"
    }
    catch {
        $reason = "Could not send Next: $($_.Exception.Message)"
        Write-SkiptifyLog "Recovery failed: $reason"
        return New-SkiptifyResult -Status "Failed" -Reason $reason -Process $confirmedSpotify
    }

    Start-Sleep -Milliseconds $PostNextDelayMs

    if (Test-SkiptifyStopRequested) {
        return New-SkiptifyResult -Status "Stopped" -Reason "Permintaan berhenti diterima sebelum Play." -Process $confirmedSpotify
    }

    $playTarget = Get-SpotifyWindowByIdentity -ProcessId $processId -WindowHandle $windowHandle
    if (-not $playTarget) {
        $reason = "Spotify was unavailable or unresponsive before Play. Last seen: $(Get-SpotifyWindowDescription (Get-SpotifyWindowSnapshot))"
        Write-SkiptifyLog "Recovery failed: $reason"
        return New-SkiptifyResult -Status "Failed" -Reason $reason
    }

    try {
        Send-SpotifyAppCommand -Command "Play" -WindowHandle $windowHandle
        Write-SkiptifyLog "Play command sent: $(Get-SpotifyWindowDescription $playTarget)"
    }
    catch {
        $reason = "Could not send Play: $($_.Exception.Message)"
        Write-SkiptifyLog "Recovery failed: $reason"
        return New-SkiptifyResult -Status "Failed" -Reason $reason -Process $playTarget
    }

    return New-SkiptifyResult -Status "CommandsSent" -Reason "Next and Play commands were sent; playback was not verified." -Process $playTarget
}

function Invoke-Skiptify {
    $badCount = 0
    Write-SkiptifyLog "Skiptify started."
    Write-SkiptifyStatus -Status "Memulai" -Message "Menyiapkan pemantauan Spotify."

    if (Test-SkiptifyStopRequested) {
        Write-SkiptifyStatus -Status "Off" -Message "Pemantauan tidak diaktifkan."
        return 0
    }

    $spotifyRunning = @(Get-SpotifyProcesses)
    if ($spotifyRunning.Count -eq 0) {
        $startup = Start-SpotifySmooth
        if ($startup.Status -ne "Started") {
            if ($startup.Status -eq "Stopped") {
                Write-SkiptifyStatus -Status "Off" -Message "Pemantauan tidak diaktifkan."
                return 0
            }
            Write-SkiptifyStatus -Status "Gagal" -Message $startup.Reason
            Write-SkiptifyLog "Skiptify stopped after startup failure: $($startup.Reason)"
            return 1
        }
    }

    Write-SkiptifyStatus -Status "Aktif" -Message "Pemantauan Spotify aktif."

    while ($true) {
        if (Test-SkiptifyStopRequested) {
            Write-SkiptifyStatus -Status "Menghentikan" -Message "Menghentikan pemantauan."
            break
        }

        $spotify = Get-SpotifyWindowSnapshot

        if ($spotify) {
            try {
                $title = $spotify.MainWindowTitle
                $isIgnored = $title -in $IgnoredTitles
                $hasDash = $title -like "*-*"

                if ((-not [string]::IsNullOrEmpty($title)) -and (-not $hasDash) -and (-not $isIgnored)) {
                    $badCount++

                    if ($badCount -ge $TriggerCount) {
                        Write-SkiptifyStatus -Status "Memulihkan" -Message "Memulihkan Spotify."
                        $recovery = Restart-SpotifySmooth
                        $badCount = 0

                        if ($recovery.Status -eq "Stopped") {
                            Write-SkiptifyStatus -Status "Menghentikan" -Message $recovery.Reason
                            break
                        }

                        if ($recovery.Status -ne "CommandsSent") {
                            Write-SkiptifyStatus -Status "Gagal" -Message $recovery.Reason
                            Write-SkiptifyLog "Skiptify stopped after recovery $($recovery.Status): $($recovery.Reason)"
                            return 1
                        }

                        Write-SkiptifyStatus -Status "Aktif" -Message "Pemantauan Spotify aktif."

                        Start-Sleep -Milliseconds 750
                    }
                }
                else {
                    $badCount = 0
                }
            }
            catch {
                $badCount = 0
            }
        }
        else {
            $badCount = 0
        }

        Start-Sleep -Milliseconds $CheckIntervalMs
    }

    Write-SkiptifyStatus -Status "Off" -Message "Pemantauan berhenti."
    return 0
}

if ($MyInvocation.InvocationName -ne ".") {
    if (Initialize-SkiptifyControl) {
        try {
            $exitCode = Invoke-Skiptify
        }
        finally {
            Dispose-SkiptifyControl
        }
        if ($exitCode -ne 0) {
            exit $exitCode
        }
    }
}
