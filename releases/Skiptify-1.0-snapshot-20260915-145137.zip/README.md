# Skiptify Desktop 1.0

Skiptify Desktop adalah UI Windows ringan dengan satu toggle On/Off. Mesin pemantauan tetap menggunakan `skiptify/skiptify.ps1`, sehingga perilaku deteksi dan pemulihan Spotify tetap sama dengan versi VBS/PS1.

## Build

Jalankan dari PowerShell 5.1 di folder proyek:

```powershell
.\build.ps1
```

Hasilnya ada di `dist\Skiptify.exe` bersama worker PowerShell dan launcher VBS. Kompilasi memakai C# compiler yang disertakan .NET Framework 4.8, tanpa dependensi NuGet atau runtime browser.

Untuk membuat installer:

```powershell
.\build.ps1 -Installer
```

Perintah tersebut memerlukan Inno Setup 6 (`ISCC.exe`). Installer dipasang per pengguna ke `%LOCALAPPDATA%\Programs\Skiptify`, membuat shortcut Start Menu, dan menawarkan shortcut desktop.

## Menjalankan

Buka `Skiptify.exe`, tekan **On**, dan biarkan aplikasi berjalan di taskbar. Tekan **Off** untuk menghentikan worker; Spotify tidak ditutup. Klik **X** menghentikan worker secara tertib lalu keluar.

UI memakai mutex `Local\Skiptify.Desktop.1.0`; worker memakai mutex `Local\Skiptify.Engine.1.0`. Karena itu hanya satu UI dan satu worker dapat berjalan untuk setiap sesi pengguna. Tombol **Start/Stop Skiptify.vbs** memakai event berhenti yang sama dengan UI.

Log runtime disimpan di `%LOCALAPPDATA%\Skiptify\Logs\skiptify.log` dengan satu arsip rotasi maksimal 1 MB. Jika folder tersebut tidak dapat ditulis, worker menggunakan folder script sebagai fallback dan tetap melanjutkan pemantauan.

## Verifikasi

```powershell
Invoke-Pester -Script .\tests\skiptify.tests.ps1 -EnableExit
```

Pengujian mencakup 12 skenario worker, stabilitas jendela, peluncuran tersembunyi, named event, dan mutex lifecycle. Pengukuran CPU/RAM serta uji restart Spotify langsung tetap perlu dilakukan pada mesin pengguna sebelum distribusi luas.
