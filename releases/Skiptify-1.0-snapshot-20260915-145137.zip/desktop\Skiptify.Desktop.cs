using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.Reflection;

[assembly: AssemblyTitle("Skiptify")]
[assembly: AssemblyDescription("Lightweight Spotify monitoring helper")]
[assembly: AssemblyProduct("Skiptify")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace SkiptifyDesktop
{
    internal static class Program
    {
        private const string UiMutexName = "Local\\Skiptify.Desktop.1.0";

        [STAThread]
        private static void Main()
        {
            bool createdNew;
            using (var mutex = new Mutex(true, UiMutexName, out createdNew))
            {
                if (!createdNew)
                {
                    MainForm.ActivateExistingWindow();
                    return;
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MainForm());
            }
        }
    }

    internal sealed class MainForm : Form
    {
        private const string StopEventName = "Local\\Skiptify.Desktop.Stop.1.0";
        private const int WorkerStopTimeoutMs = 15000;

        private readonly CheckBox toggle;
        private readonly Label statusLabel;
        private readonly Label hintLabel;
        private EventWaitHandle stopEvent;
        private Process worker;
        private System.Threading.Timer stopTimer;
        private bool transition;
        private bool closing;
        private bool allowClose;
        private string lastStatus = "Off";

        public MainForm()
        {
            Text = "Skiptify";
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = true;
            ClientSize = new Size(340, 205);
            AutoScaleMode = AutoScaleMode.Font;
            Icon = SystemIcons.Application;

            var title = new Label
            {
                Text = "Skiptify",
                Font = new Font(Font.FontFamily, 18f, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(24, 20)
            };

            var subtitle = new Label
            {
                Text = "Pemantauan Spotify",
                AutoSize = true,
                ForeColor = Color.DimGray,
                Location = new Point(27, 54)
            };

            toggle = new CheckBox
            {
                Appearance = Appearance.Button,
                AutoSize = false,
                Text = "OFF",
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font(Font.FontFamily, 10f, FontStyle.Bold),
                FlatStyle = FlatStyle.System,
                Size = new Size(126, 42),
                Location = new Point(24, 88),
                TabIndex = 0,
                AccessibleName = "Aktifkan pemantauan Skiptify",
                UseVisualStyleBackColor = true
            };
            toggle.Click += Toggle_Click;

            statusLabel = new Label
            {
                Text = "Status: Off",
                AutoEllipsis = true,
                AutoSize = false,
                Size = new Size(160, 24),
                Location = new Point(174, 97),
                ForeColor = Color.DimGray,
                TextAlign = ContentAlignment.MiddleLeft
            };

            hintLabel = new Label
            {
                Text = "Tekan On untuk mulai.",
                AutoEllipsis = true,
                AutoSize = false,
                Size = new Size(292, 24),
                Location = new Point(27, 151),
                ForeColor = Color.DimGray
            };

            Controls.Add(title);
            Controls.Add(subtitle);
            Controls.Add(toggle);
            Controls.Add(statusLabel);
            Controls.Add(hintLabel);
            AcceptButton = null;
            FormClosing += MainForm_FormClosing;
            SetStatus("Off", "Tekan On untuk mulai.");
            Shown += MainForm_Shown;
        }

        public static void ActivateExistingWindow()
        {
            IntPtr handle = NativeMethods.FindWindow(null, "Skiptify");
            if (handle != IntPtr.Zero)
            {
                NativeMethods.ShowWindow(handle, NativeMethods.SwRestore);
                NativeMethods.SetForegroundWindow(handle);
            }
        }

        private void Toggle_Click(object sender, EventArgs e)
        {
            if (transition)
            {
                return;
            }

            if (toggle.Checked)
            {
                StartWorker();
            }
            else
            {
                StopWorker(false);
            }
        }

        private void MainForm_Shown(object sender, EventArgs e)
        {
            // Show a useful explanation when the legacy VBS launcher owns the
            // engine. This check is one-shot and does not poll Spotify.
            if (IsEngineRunning())
            {
                SetStatus("Konflik", "Skiptify sudah berjalan dari launcher lain.");
            }
        }

        private static bool IsEngineRunning()
        {
            bool createdNew;
            using (var mutex = new Mutex(false, "Local\\Skiptify.Engine.1.0", out createdNew))
            {
                try
                {
                    if (mutex.WaitOne(0))
                    {
                        mutex.ReleaseMutex();
                        return false;
                    }
                    return true;
                }
                catch (AbandonedMutexException)
                {
                    try { mutex.ReleaseMutex(); } catch { }
                    return false;
                }
            }
        }

        private void StartWorker()
        {
            if (worker != null || transition)
            {
                return;
            }

            if (IsEngineRunning())
            {
                toggle.Checked = false;
                SetStatus("Konflik", "Skiptify sudah berjalan dari launcher lain.");
                return;
            }

            string scriptPath = Path.Combine(Application.StartupPath, "skiptify.ps1");
            if (!File.Exists(scriptPath))
            {
                toggle.Checked = false;
                SetStatus("Gagal", "skiptify.ps1 tidak ditemukan.");
                return;
            }

            try
            {
                bool createdNew;
                stopEvent = new EventWaitHandle(false, EventResetMode.ManualReset, StopEventName, out createdNew);
                stopEvent.Reset();

                string powershell = FindPowerShell();
                var info = new ProcessStartInfo
                {
                    FileName = powershell,
                    Arguments = "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "
                        + Quote(scriptPath)
                        + " -HostPid " + Process.GetCurrentProcess().Id
                        + " -StopEventName " + Quote(StopEventName),
                    WorkingDirectory = Application.StartupPath,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };

                worker = new Process { StartInfo = info, EnableRaisingEvents = true };
                worker.OutputDataReceived += Worker_OutputDataReceived;
                worker.ErrorDataReceived += Worker_ErrorDataReceived;
                worker.Exited += Worker_Exited;
                if (!worker.Start())
                {
                    throw new InvalidOperationException("PowerShell tidak dapat dijalankan.");
                }

                transition = true;
                toggle.Enabled = false;
                toggle.Text = "...";
                SetStatus("Memulai", "Menyiapkan pemantauan Spotify.");
                worker.BeginOutputReadLine();
                worker.BeginErrorReadLine();
            }
            catch (Exception ex)
            {
                CleanupWorker();
                toggle.Checked = false;
                SetStatus("Gagal", ShortMessage(ex.Message));
            }
        }

        private void StopWorker(bool forClose)
        {
            if (worker == null)
            {
                toggle.Checked = false;
                toggle.Enabled = true;
                SetStatus("Off", "Pemantauan berhenti.");
                return;
            }

            if (transition && lastStatus == "Menghentikan")
            {
                return;
            }

            closing = closing || forClose;
            transition = true;
            toggle.Checked = false;
            toggle.Enabled = false;
            toggle.Text = "...";
            SetStatus("Menghentikan", "Menghentikan pemantauan.");

            try
            {
                if (stopEvent != null)
                {
                    stopEvent.Set();
                }
            }
            catch
            {
                // The worker exit handler still performs cleanup if the event is gone.
            }

            if (stopTimer == null)
            {
                stopTimer = new System.Threading.Timer(ForceStopWorker, null, WorkerStopTimeoutMs, Timeout.Infinite);
            }
        }

        private void ForceStopWorker(object state)
        {
            try
            {
                if (worker != null && !worker.HasExited)
                {
                    worker.Kill();
                }
            }
            catch
            {
                // The process may have exited between HasExited and Kill.
            }
        }

        private void Worker_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(e.Data))
            {
                string status;
                string message;
                if (TryParseStatus(e.Data, out status, out message))
                {
                    PostToUi(() => ApplyWorkerStatus(status, message));
                }
            }
        }

        private void Worker_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            // PowerShell warnings and diagnostics remain in the worker log. Do not
            // update the UI for every diagnostic line.
        }

        private void Worker_Exited(object sender, EventArgs e)
        {
            PostToUi(HandleWorkerExit);
        }

        private void ApplyWorkerStatus(string status, string message)
        {
            if (IsDisposed || worker == null)
            {
                return;
            }

            SetStatus(status, string.IsNullOrWhiteSpace(message) ? DefaultMessage(status) : message);

            if (status == "Aktif")
            {
                transition = false;
                toggle.Enabled = true;
                toggle.Checked = true;
                toggle.Text = "ON";
            }
            else if (status == "Gagal" || status == "Konflik")
            {
                transition = false;
                toggle.Enabled = true;
                toggle.Checked = false;
                toggle.Text = "OFF";
            }
        }

        private void HandleWorkerExit()
        {
            if (IsDisposed)
            {
                return;
            }

            int exitCode = -1;
            try { exitCode = worker == null ? -1 : worker.ExitCode; } catch { }
            bool wasStopping = lastStatus == "Menghentikan" || closing;
            CleanupWorker();

            transition = false;
            toggle.Enabled = true;
            toggle.Checked = false;
            toggle.Text = "OFF";

            if (!wasStopping && exitCode != 0 && lastStatus != "Gagal" && lastStatus != "Konflik")
            {
                SetStatus("Gagal", "Worker berhenti secara tidak terduga.");
            }
            else if (lastStatus != "Gagal" && lastStatus != "Konflik")
            {
                SetStatus("Off", "Pemantauan berhenti.");
            }

            if (closing)
            {
                allowClose = true;
                BeginInvoke(new Action(Close));
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (allowClose || worker == null)
            {
                CleanupWorker();
                return;
            }

            e.Cancel = true;
            StopWorker(true);
        }

        private void CleanupWorker()
        {
            if (stopTimer != null)
            {
                stopTimer.Dispose();
                stopTimer = null;
            }

            if (worker != null)
            {
                worker.OutputDataReceived -= Worker_OutputDataReceived;
                worker.ErrorDataReceived -= Worker_ErrorDataReceived;
                worker.Exited -= Worker_Exited;
                worker.Dispose();
                worker = null;
            }

            if (stopEvent != null)
            {
                stopEvent.Dispose();
                stopEvent = null;
            }
        }

        private void PostToUi(Action action)
        {
            try
            {
                if (!IsDisposed && IsHandleCreated)
                {
                    BeginInvoke(action);
                }
            }
            catch (InvalidOperationException) { }
        }

        private void SetStatus(string status, string message)
        {
            lastStatus = status;
            statusLabel.Text = "Status: " + status;
            hintLabel.Text = message;
            statusLabel.ForeColor = status == "Gagal" || status == "Konflik" ? Color.Firebrick : Color.DimGray;
        }

        private static string FindPowerShell()
        {
            string candidate = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
            return File.Exists(candidate) ? candidate : "powershell.exe";
        }

        private static string Quote(string value)
        {
            return "\"" + value.Replace("\"", "\\\"") + "\"";
        }

        private static string ShortMessage(string message)
        {
            if (string.IsNullOrWhiteSpace(message)) return "Tidak dapat menjalankan worker.";
            return message.Length > 120 ? message.Substring(0, 120) : message;
        }

        private static string DefaultMessage(string status)
        {
            switch (status)
            {
                case "Memulai": return "Menyiapkan pemantauan Spotify.";
                case "Aktif": return "Pemantauan Spotify aktif.";
                case "Memulihkan": return "Memulihkan Spotify.";
                case "Menghentikan": return "Menghentikan pemantauan.";
                case "Off": return "Pemantauan berhenti.";
                default: return "";
            }
        }

        private static bool TryParseStatus(string line, out string status, out string message)
        {
            status = null;
            message = null;
            Match statusMatch = Regex.Match(line, "\\\"status\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"])*)\\\"");
            if (!statusMatch.Success) return false;
            status = Regex.Unescape(statusMatch.Groups[1].Value);
            Match messageMatch = Regex.Match(line, "\\\"message\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"])*)\\\"");
            if (messageMatch.Success) message = Regex.Unescape(messageMatch.Groups[1].Value);
            return true;
        }

        private static class NativeMethods
        {
            public const int SwRestore = 9;

            [System.Runtime.InteropServices.DllImport("user32.dll")]
            public static extern IntPtr FindWindow(string className, string windowName);

            [System.Runtime.InteropServices.DllImport("user32.dll")]
            public static extern bool ShowWindow(IntPtr hWnd, int command);

            [System.Runtime.InteropServices.DllImport("user32.dll")]
            public static extern bool SetForegroundWindow(IntPtr hWnd);
        }
    }
}
