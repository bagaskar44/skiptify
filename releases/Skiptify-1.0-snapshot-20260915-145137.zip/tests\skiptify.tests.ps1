﻿$scriptPath = Join-Path -Path $PSScriptRoot -ChildPath "..\skiptify\skiptify.ps1"
. $scriptPath

function New-FakeSpotifyWindow {
    param(
        [int]$Id,
        [IntPtr]$Handle,
        [string]$Title = "Spotify Free",
        [bool]$Responding = $true
    )

    [PSCustomObject]@{
        Id = $Id
        MainWindowHandle = $Handle
        MainWindowTitle = $Title
        Responding = $Responding
    }
}

function Set-SpotifySnapshots {
    param([array]$Snapshots)

    $script:snapshots = New-Object System.Collections.Queue
    foreach ($snapshot in $Snapshots) {
        $script:snapshots.Enqueue($snapshot)
    }
}

Describe "Skiptify recovery" {
    BeforeEach {
        $script:commands = @()
        Set-SpotifySnapshots @()

        Mock Write-SkiptifyLog {}
        Mock Start-Sleep {}
        Mock Get-SpotifyProcesses { @() }
        Mock Get-SpotifyMainWindow { $null }
        Mock Minimize-SpotifyWindow {}
        Mock Start-SpotifyUri { $true }
        Mock Stop-SpotifyProcesses {}
        Mock Send-SpotifyAppCommand {
            param($Command, $WindowHandle)
            $script:commands += $Command
        }
        Mock Get-SpotifyWindowSnapshot {
            if ($script:snapshots.Count -eq 0) {
                return $null
            }

            return $script:snapshots.Dequeue()
        }
    }

    It "waits for five stable Spotify Free checks after missing and blank snapshots" {
        $free = New-FakeSpotifyWindow -Id 101 -Handle ([IntPtr]11)
        $blank = New-FakeSpotifyWindow -Id 101 -Handle ([IntPtr]11) -Title ""
        Set-SpotifySnapshots @($null, $blank, $free, $free, $free, $free, $free)

        $result = Wait-ForSpotifyFreeReady -TimeoutMs 5000 -RequiredStableChecks 5

        $result.Status | Should Be "Started"
        $result.Process.Id | Should Be 101
    }

    It "resets the stable count when the window identity or title changes" {
        $first = New-FakeSpotifyWindow -Id 101 -Handle ([IntPtr]11)
        $nonFree = New-FakeSpotifyWindow -Id 101 -Handle ([IntPtr]11) -Title "Spotify"
        $second = New-FakeSpotifyWindow -Id 202 -Handle ([IntPtr]22)
        Set-SpotifySnapshots @($first, $first, $nonFree, $second, $second, $second, $second, $second)

        $result = Wait-ForSpotifyFreeReady -TimeoutMs 5000 -RequiredStableChecks 5

        $result.Status | Should Be "Started"
        $result.Process.Id | Should Be 202
    }

    It "times out without issuing playback commands" {
        $result = Wait-ForSpotifyFreeReady -TimeoutMs 0 -RequiredStableChecks 5

        $result.Status | Should Be "TimedOut"
        Assert-MockCalled -Scope It Send-SpotifyAppCommand -Times 0 -Exactly
    }

    It "minimizes the first window while its title is still blank" {
        $blank = New-FakeSpotifyWindow -Id 101 -Handle ([IntPtr]11) -Title ""
        $free = New-FakeSpotifyWindow -Id 101 -Handle ([IntPtr]11)
        Set-SpotifySnapshots @($blank, $free)

        $result = Wait-ForSpotifyFreeReady -TimeoutMs 5000 -RequiredStableChecks 1

        $result.Status | Should Be "Started"
        Assert-MockCalled -Scope It Minimize-SpotifyWindow -Times 2 -Exactly -ParameterFilter { $WindowHandle -eq [IntPtr]11 }
    }

    It "waits again when Spotify changes during the post-ready delay, then sends Next and Play once" {
        $first = New-FakeSpotifyWindow -Id 101 -Handle ([IntPtr]11)
        $second = New-FakeSpotifyWindow -Id 202 -Handle ([IntPtr]22)
        $secondSong = New-FakeSpotifyWindow -Id 202 -Handle ([IntPtr]22) -Title "Song - Artist"
        Set-SpotifySnapshots @(
            $first, $first, $first, $first, $first,
            $second, $second,
            $second, $second, $second, $second, $second,
            $second, $secondSong
        )

        $result = Restart-SpotifySmooth

        $result.Status | Should Be "CommandsSent"
        $script:commands | Should Be @("Next", "Play")
    }

    It "does not retry Next when Spotify disappears before Play" {
        $free = New-FakeSpotifyWindow -Id 101 -Handle ([IntPtr]11)
        Set-SpotifySnapshots @($free, $free, $free, $free, $free, $free, $null)

        $result = Restart-SpotifySmooth

        $result.Status | Should Be "Failed"
        $script:commands | Should Be @("Next")
    }

    It "fails recovery when the Spotify URI cannot be opened" {
        Mock Start-SpotifyUri { $false }

        $result = Restart-SpotifySmooth

        $result.Status | Should Be "Failed"
        @($script:commands).Count | Should Be 0
    }
    It "bounds recovery even when each ready window changes before confirmation" {
        $savedTimeout = $RecoveryTimeoutMs
        $savedDelay = $PostReadyDelayMs
        try {
            $RecoveryTimeoutMs = 30
            $PostReadyDelayMs = 0
            $free = New-FakeSpotifyWindow -Id 101 -Handle ([IntPtr]11)
            Mock Wait-ForSpotifyFreeReady {
                New-SkiptifyResult -Status "Started" -Process $free
            }
            Mock Get-SpotifyWindowByIdentity { $null }

            $result = Restart-SpotifySmooth

            $result.Status | Should Be "TimedOut"
            Assert-MockCalled -Scope It Send-SpotifyAppCommand -Times 0 -Exactly
        }
        finally {
            $RecoveryTimeoutMs = $savedTimeout
            $PostReadyDelayMs = $savedDelay
        }
    }


}

Describe "Spotify background launch" {
    BeforeEach {
        $script:SpotifyExecutablePath = 'C:\Spotify\Spotify.exe'
        Mock Write-SkiptifyLog {}
        Mock Test-Path { $true }
        Mock Start-Process {}
    }

    It "launches the cached executable hidden without opening the URI" {
        Start-SpotifyUri | Should Be $true
        Assert-MockCalled -Scope It Start-Process -Times 1 -Exactly -ParameterFilter {
            $FilePath -eq 'C:\Spotify\Spotify.exe' -and $WindowStyle -eq 'Hidden'
        }
        Assert-MockCalled -Scope It Start-Process -Times 0 -Exactly -ParameterFilter { $FilePath -eq 'spotify:' }
    }

    It "falls back to the URI when direct launch fails" {
        Mock Start-Process { throw 'Executable unavailable' } -ParameterFilter { $FilePath -ne 'spotify:' }
        Start-SpotifyUri | Should Be $true
        Assert-MockCalled -Scope It Start-Process -Times 1 -Exactly -ParameterFilter { $FilePath -eq 'spotify:' }
    }
}

Describe "Skiptify worker controls" {
    It "observes a named stop event without polling Spotify" {
        $name = "Local\Skiptify.Test.Stop.$PID"
        $event = New-Object System.Threading.EventWaitHandle($false, [System.Threading.EventResetMode]::ManualReset, $name)
        try {
            $script:StopEvent = $event
            $script:StatusOutputEnabled = $false
            (Test-SkiptifyStopRequested) | Should Be $false
            $event.Set() | Should Be $true
            (Test-SkiptifyStopRequested) | Should Be $true
        }
        finally {
            $script:StopEvent = $null
            $event.Dispose()
        }
    }

    It "acquires and releases the engine mutex for one worker" {
        try {
            Initialize-SkiptifyControl | Should Be $true
            $script:EngineMutex | Should Not Be $null
        }
        finally {
            Dispose-SkiptifyControl
        }
        $script:EngineMutex | Should Be $null
    }
}

